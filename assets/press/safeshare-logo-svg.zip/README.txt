Placeholder SVG logo (shield). Replace with final brand graphic.
License: Demo only.